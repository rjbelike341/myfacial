package cn.facial.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.facial.connection.DbCon;
import cn.facial.dao.ProductDao;


@WebServlet("/add-product")
public class AddProductServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html;charset=UTF-8");
		try (PrintWriter out = response.getWriter()) {
			String name = request.getParameter("name");
			String category = request.getParameter("category");
			String p = request.getParameter("price");
			String image = request.getParameter("image");
			
			Double price =Double.parseDouble(p);

			ProductDao pdao = new ProductDao(DbCon.getConnection());
			pdao.addProduct(name,category,price,image);
			response.sendRedirect("index.jsp");

		} catch (ClassNotFoundException|SQLException e) {
			e.printStackTrace();
		} 

	}
		
		
 }


