package com.virtusa.project.service;

import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.virtusa.project.model.ERole;
import com.virtusa.project.model.Role;
import com.virtusa.project.model.User;
import com.virtusa.project.repository.UserRepository;

@Service
public class SignupService {

	@Autowired
	private UserRepository userModelRepository;
	public ResponseEntity<Object> saveUser(User user) {
		
		if(userModelRepository.existsById(user.getEmail())) {
			return new ResponseEntity<>("EMAIL IS ALREADY EXISTS",HttpStatus.IM_USED);
		}
		else if(userModelRepository.existsByUsername(user.getUsername())) {
			return new ResponseEntity<>("USERNAME ALREADY EXISTS",HttpStatus.IM_USED);
			
		}
		else {
			BCryptPasswordEncoder encoder=new BCryptPasswordEncoder();
			user.setPassword(encoder.encode(user.getPassword()));
			Set<Role> roles = new HashSet<>();
			roles.add(new Role(ERole.ROLE_CUSTOMER));
			user.setRoles(roles);
			user.setActive(true);
			userModelRepository.save(user);
			return new ResponseEntity<>("ACCOUNT CREATED SUCCESSFULLY",HttpStatus.OK);
		}
	}

}
