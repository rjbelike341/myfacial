package com.virtusa.project.model;
public enum ERole {
ROLE_ADMIN,
ROLE_CUSTOMER
}