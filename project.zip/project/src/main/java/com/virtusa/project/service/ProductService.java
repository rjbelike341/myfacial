package com.virtusa.project.service;


import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;


import com.virtusa.project.model.ProductModel;
import com.virtusa.project.repository.ProductModelRepository;

@Service
public class ProductService {

	@Autowired
	private ProductModelRepository prRepository;
	
	public ResponseEntity<Object>  productSave (ProductModel data){
		prRepository.save(data);
		return new ResponseEntity<>("PRODUCT ADDED SUCCESSFULLY",HttpStatus.OK);
	}
	

	public List<ProductModel> getAllProducts(){
		return prRepository.findAll();
	}
	
	public void deleteProduct(int id){
		prRepository.deleteById(id);
	}
	public void productEditSave(ProductModel data){
		prRepository.save(data);
		
	}
	public  ProductModel getProductById(int id){
		return prRepository.findById(id).orElse(null);
	}
}
