package com.virtusa.project.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.virtusa.project.model.CartModel;
import com.virtusa.project.request.AddCartReqest;
import com.virtusa.project.service.CartService;
@CrossOrigin(origins = "*")
@RestController
public class CartController {

	@Autowired
	private CartService cartService;
	@PostMapping("/addCart")
	public ResponseEntity<Object> addCart(@RequestBody AddCartReqest c){
		CartModel cm = new CartModel();
		cm.setPrice(c.getPrice());
		cm.setProductName(c.getProductName());
		cm.setQuantity(c.getQuantity());
		cm.setUserId(c.getUserId());
		return cartService.addCart(cm);
	}
	@GetMapping("/cart/{id}")
	public ResponseEntity<Object> showCart(@PathVariable("id") String id){
		return cartService.showCart(id);
	}
	@PutMapping("cart/changeQuantity/{id}/{quantity}")
	public void showCart(@PathVariable("id") Long id,@PathVariable("quantity") int quantity){
		cartService.changeQuantity(id,quantity);
	}
	@DeleteMapping("/cart/delete/{id}")
	public void deleteCartItem(@PathVariable("id") Long id) {
		cartService.deleteCartItem(id);
	}

}
