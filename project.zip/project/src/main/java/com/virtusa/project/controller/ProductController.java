package com.virtusa.project.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import org.springframework.web.bind.annotation.RestController;


import com.virtusa.project.model.ProductModel;
import com.virtusa.project.request.AddProductRequest;
import com.virtusa.project.request.EditProductRequest;
import com.virtusa.project.service.ProductService;

@CrossOrigin(origins = "*")
@RestController
public class ProductController {

	@Autowired
	private ProductService productService;
	
	@PreAuthorize("hasRole('ROLE_ADMIN')")
	@PostMapping("/admin/addProduct")
	public ResponseEntity<Object>  addProduct(@RequestBody AddProductRequest e) {
		ProductModel p = new ProductModel();
		p.setBrand(e.getBrand());
		p.setCategory(e.getCategory());
		p.setDescription(e.getDescription());
		p.setImage(e.getImage());
		p.setName(e.getName());
		p.setPrice(e.getPrice());
		p.setQuantity(e.getQuantity());
		p.setProductId(e.getProductId());
		return productService.productSave(p);
	}
	

	@DeleteMapping("/admin/delete/{id}")
	public void deleteCartItem(@PathVariable("id") int id) {
		productService.deleteProduct(id);
	}
	
	@GetMapping("/admin/productEdit/{id}")
	public  ProductModel productEditData(@PathVariable("id") int id){
		return productService.getProductById(id);
	}
	@GetMapping("/home")
	public List<ProductModel> getHomeProduct(){
		return productService.getAllProducts();
	}
	@GetMapping("/admin")
	public List<ProductModel> getProduct(){
		return productService.getAllProducts();
	}
	@PostMapping("/admin/productEdit/{id}")
	public void productEditSave(@PathVariable("id") int id, @RequestBody EditProductRequest e){
		ProductModel p = new ProductModel();
		p.setBrand(e.getBrand());
		p.setCategory(e.getCategory());
		p.setDescription(e.getDescription());
		p.setImage(e.getImage());
		p.setName(e.getImage());
		p.setPrice(e.getPrice());
		p.setQuantity(e.getQuantity());
		p.setProductId(id);		
		productService.productEditSave(p);
	}

}
