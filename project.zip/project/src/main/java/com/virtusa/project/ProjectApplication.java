package com.virtusa.project;

import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import com.virtusa.project.model.ERole;
import com.virtusa.project.model.Role;
import com.virtusa.project.model.User;
import com.virtusa.project.repository.UserRepository;

@SpringBootApplication
public class ProjectApplication implements CommandLineRunner {

	@Autowired
	private UserRepository repository;
	@Autowired 
	public static void main(String[] args) {
		SpringApplication.run(ProjectApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		BCryptPasswordEncoder encoder=new BCryptPasswordEncoder();
		User u1=new User();
		u1.setEmail("admin@gmail.com");
		u1.setPassword(encoder.encode("admin"));
		u1.setUsername("virtusa");
		Set<Role> roles = new HashSet<>();
		roles.add(new Role(ERole.ROLE_ADMIN));
		u1.setRoles(roles);
		u1.setActive(true);
		repository.save(u1);
	}

}
