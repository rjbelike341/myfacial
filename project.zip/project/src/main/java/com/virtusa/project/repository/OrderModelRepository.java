package com.virtusa.project.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;


import com.virtusa.project.model.OrderModel;

public interface OrderModelRepository extends JpaRepository<OrderModel,Long> {
	public List<OrderModel> findAllByUserId(String userId);
}
