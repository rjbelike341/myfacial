package com.virtusa.project.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.virtusa.project.model.CartModel;
import com.virtusa.project.repository.CartModelRepository;

@Service
public class CartService {

	@Autowired
	private CartModelRepository cartModelRepository;
	
	public ResponseEntity<Object> addCart(CartModel cart){
		Optional<CartModel> cartModel=cartModelRepository.findByProductNameAndUserId(cart.getProductName(),cart.getUserId());
		if(cartModel.isPresent()) {
			CartModel c=cartModel.get();
			c.setQuantity(c.getQuantity()+cart.getQuantity());
			cartModelRepository.save(c);
			return new ResponseEntity<>(cart.getQuantity()+"Items Increased successfully.",HttpStatus.OK);
		}
		else {
			if(cartModelRepository.countByUserId(cart.getUserId())==5) {
				return new ResponseEntity<>("Maximum allowed items are Five!",HttpStatus.OK);
			}
			cartModelRepository.save(cart);
			return new ResponseEntity<>("Added Successfully",HttpStatus.OK);
		}
	}
	public ResponseEntity<Object> showCart(String id){
		List<CartModel> cart=cartModelRepository.findAllByUserId(id);
		return new ResponseEntity<>(cart,HttpStatus.OK);
	}
	public void changeQuantity(Long id,int quantity) {
		CartModel cart=cartModelRepository.getById(id);
		cart.setQuantity(quantity);
		cartModelRepository.save(cart);
	}
	 public void deleteCartItem(Long id) {
		 cartModelRepository.deleteById(id);
	 }
}
