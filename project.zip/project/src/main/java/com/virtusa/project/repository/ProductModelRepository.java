package com.virtusa.project.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.virtusa.project.model.ProductModel;

public interface ProductModelRepository extends JpaRepository<ProductModel,Integer>{

}
