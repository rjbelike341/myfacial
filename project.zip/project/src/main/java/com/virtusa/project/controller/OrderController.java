package com.virtusa.project.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.virtusa.project.model.OrderModel;
import com.virtusa.project.request.PlaceOrderRequest;
import com.virtusa.project.service.OrderService;

@CrossOrigin(origins = "*")
@RestController
public class OrderController {

	@Autowired
	private OrderService orderService;
	@PostMapping("/placeOrder")
	public ResponseEntity<Object> placeOrder(@RequestBody PlaceOrderRequest o ){
		OrderModel p = new OrderModel();
		p.setUserId(o.getUserId());
		p.setPrice(o.getPrice());
		p.setProductName(o.getProductName());
		p.setQuantity(o.getQuantity());
		p.setStatus(o.getStatus());
		p.setTotalPrice(o.getTotalPrice());
		
		return orderService.placeOrder(p);
	}
	@PostMapping("/saveOrder/{id}")
	public ResponseEntity<Object> saveProduct(@PathVariable("id") String id){
		return orderService.saveProduct(id);
	}
	@GetMapping("/orders/{id}")
	public ResponseEntity<Object> getUserProducts(@PathVariable("id") String id){
		return orderService.getUserProducts(id);
	}
	@GetMapping("/admin/orders")
	public ResponseEntity<Object> getAllOrders(){
		return orderService.getAllOrders();
	}
}
