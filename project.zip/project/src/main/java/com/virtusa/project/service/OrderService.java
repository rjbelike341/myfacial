package com.virtusa.project.service;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.virtusa.project.model.CartModel;
import com.virtusa.project.model.OrderModel;
import com.virtusa.project.repository.CartModelRepository;
import com.virtusa.project.repository.OrderModelRepository;
import com.virtusa.project.response.OrderTemp;

@Service
@Transactional 
public class OrderService {

	@Autowired
	private OrderModelRepository orderModelRepository;
	@Autowired
	private CartModelRepository cartModelRepository;
	
	public ResponseEntity<Object> placeOrder(OrderModel order){
		order.setTotalPrice(order.getPrice()*order.getQuantity());
		order.setStatus("ordered");
		orderModelRepository.save(order);
		return new ResponseEntity<>("Order Place Successfully",HttpStatus.OK);
	}
	public ResponseEntity<Object> saveProduct(String id){
		List<CartModel> cart=cartModelRepository.findAllByUserId(id);
		for(CartModel c:cart) {
			OrderModel order=new OrderModel(c.getUserId(),c.getProductName(),c.getQuantity(),c.getPrice()*c.getQuantity(),"ordered",c.getPrice());
			orderModelRepository.save(order);
		}
		cartModelRepository.deleteByUserId(id);
		return new ResponseEntity<>("Order Placed Successfully",HttpStatus.OK);
	}
	public ResponseEntity<Object> getUserProducts(String id){
		List<OrderModel> order=orderModelRepository.findAllByUserId(id);
		List<OrderTemp> userOrders=new ArrayList<>();
		for(OrderModel o:order) {
			userOrders.add(new OrderTemp(o.getProductName(),o.getPrice(),o.getTotalPrice(),o.getQuantity()));
		}
		return new ResponseEntity<>(userOrders,HttpStatus.OK);
	}
	public ResponseEntity<Object> getAllOrders(){
		List<OrderModel> orders=orderModelRepository.findAll();
		return new ResponseEntity<>(orders,HttpStatus.OK);
	}
}
