package com.virtusa.project.response;

public class OrderTemp {

	private String productName;
	private int price;
	private int totalPrice;
	private int quantity;
	public OrderTemp() {
		super();
	}
	public OrderTemp(String productName, int price, int totalPrice, int quantity) {
		super();
		this.productName = productName;
		this.price = price;
		this.totalPrice = totalPrice;
		this.quantity = quantity;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getTotalPrice() {
		return totalPrice;
	}
	public void setTotalPrice(int totalPrice) {
		this.totalPrice = totalPrice;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
}
