package com.virtusa.project.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.virtusa.project.model.User;
import com.virtusa.project.request.SaveUserRequest;
import com.virtusa.project.service.SignupService;

@CrossOrigin(origins = "*")
@RestController
public class SignupController {

	@Autowired
	private SignupService signupService;
	@PostMapping("/signup")
	public ResponseEntity<Object>  saveUser(@RequestBody SaveUserRequest s) {
		User u = new User();
		u.setEmail(s.getEmail());
		u.setPassword(s.getPassword());
		u.setUsername(s.getUsername());
		u.setActive(s.isActive());
		u.setRoles(s.getRoles());
		
		return signupService.saveUser(u);
	}
}
