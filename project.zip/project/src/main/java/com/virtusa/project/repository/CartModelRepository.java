package com.virtusa.project.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.virtusa.project.model.CartModel;

public interface CartModelRepository extends JpaRepository<CartModel,Long> {

	public Optional<CartModel> findByProductNameAndUserId(String productName,String userId);
	public int countByUserId(String userId);
	public List<CartModel> findAllByUserId(String userId);
	public void deleteByUserId(String userId);
}
